import json
import os
import time
from tkinter import *
from tkinter import messagebox
from datetime import datetime, timedelta
import threading
from plyer import notification

class WaterTracker:
    def __init__(self):
        self.users_file = "users.json"
        self.data_file = "water_data.json"
        self.notifications_file = "notifications.json"
        self.current_user = None
        self.initialize_files()
        self.notification_thread = None
        self.running = True

    def initialize_files(self):
        """Инициализирует файлы с проверкой их валидности"""
        for file, default in [
            (self.users_file, {"users": []}),
            (self.data_file, {}),
            (self.notifications_file, {})
        ]:
            if not os.path.exists(file):
                with open(file, 'w') as f:
                    json.dump(default, f, indent=4)
            else:
                try:
                    with open(file, 'r') as f:
                        json.load(f)
                except json.JSONDecodeError:
                    with open(file, 'w') as f:
                        json.dump(default, f, indent=4)

    def register_user(self, login, password):
        """Регистрирует нового пользователя"""
        try:
            with open(self.users_file, 'r+') as f:
                data = json.load(f)
                
                if any(user["login"] == login for user in data["users"]):
                    return False
                    
                data["users"].append({"login": login, "password": password})
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
                
            self.init_user_data(login)
            return True
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось зарегистрироваться: {str(e)}")
            return False

    def init_user_data(self, login):
        """Инициализирует данные пользователя"""
        try:
            with open(self.data_file, 'r+') as f:
                data = json.load(f)
                if login not in data:
                    data[login] = {
                        "daily_goal": 2000,
                        "current_volume": 0,
                        "reminder_interval": 60,
                        "last_drink_time": None,
                        "notifications_enabled": True  # Добавляем по умолчанию
                    }
                    f.seek(0)
                    json.dump(data, f, indent=4)
                    f.truncate()
        except Exception as e:
            print(f"Ошибка инициализации данных: {str(e)}")

    def login_user(self, login, password):
        """Аутентификация пользователя"""
        try:
            with open(self.users_file, 'r') as f:
                data = json.load(f)
                for user in data["users"]:
                    if user["login"] == login and user["password"] == password:
                        self.current_user = login
                        self.start_notification_thread()
                        return True
            return False
        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка входа: {str(e)}")
            return False

    def add_water(self, volume):
        """Добавляет выпитую воду"""
        try:
            with open(self.data_file, 'r+') as f:
                data = json.load(f)
                user_data = data.setdefault(self.current_user, {
                    "daily_goal": 2000,
                    "current_volume": 0,
                    "reminder_interval": 60,
                    "last_drink_time": None,
                    "notifications_enabled": True  # Значение по умолчанию
                })
                
                user_data["current_volume"] += volume
                user_data["last_drink_time"] = str(datetime.now())
                
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
            
            self.save_last_drink_time()
            return True
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить данные: {str(e)}")
            return False

    def get_user_data(self):
        """Получает данные пользователя с гарантией наличия notifications_enabled"""
        try:
            with open(self.data_file, 'r') as f:
                data = json.load(f)
                user_data = data.get(self.current_user, {
                    "daily_goal": 2000,
                    "current_volume": 0,
                    "reminder_interval": 60,
                    "last_drink_time": None,
                    "notifications_enabled": True  # Значение по умолчанию
                })
                
                # Гарантируем наличие ключа
                if "notifications_enabled" not in user_data:
                    user_data["notifications_enabled"] = True
                
                return user_data
        except Exception:
            return {
                "daily_goal": 2000,
                "current_volume": 0,
                "reminder_interval": 60,
                "last_drink_time": None,
                "notifications_enabled": True  # Значение по умолчанию
            }

    def update_settings(self, daily_goal, reminder_interval, notifications_enabled):
        """Обновляет настройки пользователя"""
        try:
            with open(self.data_file, 'r+') as f:
                data = json.load(f)
                user_data = data.setdefault(self.current_user, {
                    "daily_goal": 2000,
                    "current_volume": 0,
                    "reminder_interval": 60,
                    "last_drink_time": None,
                    "notifications_enabled": True  # Значение по умолчанию
                })
                
                user_data["daily_goal"] = daily_goal
                user_data["reminder_interval"] = reminder_interval
                user_data["notifications_enabled"] = notifications_enabled
                
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
            
            self.start_notification_thread()
            return True
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось обновить настройки: {str(e)}")
            return False

    def save_last_drink_time(self):
        """Сохраняет время последнего приема воды для уведомлений"""
        try:
            with open(self.notifications_file, 'r+') as f:
                data = json.load(f)
                data[self.current_user] = str(datetime.now())
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
        except Exception as e:
            print(f"Ошибка сохранения времени уведомления: {str(e)}")

    def check_notifications(self):
        """Проверяет необходимость показа уведомлений"""
        while self.running:
            try:
                data = self.get_user_data()
                
                if not data.get("notifications_enabled", True):
                    time.sleep(60)
                    continue
                
                # Проверяем, когда было последнее уведомление
                last_notified = None
                if os.path.exists(self.notifications_file):
                    with open(self.notifications_file, 'r') as f:
                        notifications_data = json.load(f)
                        last_notified_str = notifications_data.get(self.current_user)
                        if last_notified_str:
                            last_notified = datetime.strptime(last_notified_str, "%Y-%m-%d %H:%M:%S.%f")
                
                interval_minutes = data.get("reminder_interval", 60)
                if last_notified and (datetime.now() - last_notified) < timedelta(minutes=interval_minutes):
                    time.sleep(60)
                    continue
                
                # Показываем уведомление
                notification.notify(
                    title="Водяной - Напоминание",
                    message="Пора выпить воды!",
                    app_name="Водяной",
                    timeout=10
                )
                
                # Обновляем время последнего уведомления
                self.save_last_drink_time()
                
                time.sleep(60)
            except Exception as e:
                print(f"Ошибка в потоке уведомлений: {str(e)}")
                time.sleep(60)

    def start_notification_thread(self):
        """Запускает поток для проверки уведомлений"""
        if self.notification_thread and self.notification_thread.is_alive():
            self.running = False
            self.notification_thread.join()
        
        self.running = True
        self.notification_thread = threading.Thread(target=self.check_notifications, daemon=True)
        self.notification_thread.start()

    def stop_notification_thread(self):
        """Останавливает поток уведомлений"""
        self.running = False
        if self.notification_thread and self.notification_thread.is_alive():
            self.notification_thread.join()

class AuthWindow:
    def __init__(self, root, tracker):
        self.root = root
        self.tracker = tracker
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Водяной • Авторизация")
        self.root.geometry("400x600")
        self.root.resizable(False, False)
        self.root.configure(bg="#EBD7CE")
        center_window(self.root, 400, 600)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#EBD7CE", padx=30, pady=40)
        main_frame.pack(expand=True, fill=BOTH)
        
        # Логотип
        logo_frame = Frame(main_frame, bg="#EBD7CE")
        logo_frame.pack(pady=(0, 30))
        
        Label(logo_frame, text="💧", font=("Arial", 48), bg="#EBD7CE", fg="#836871").pack()
        Label(logo_frame, text="Водяной", font=("Arial", 24, "bold"), bg="#EBD7CE", fg="#836871").pack(pady=(10, 0))
        Label(logo_frame, text="Контроль питьевого режима", font=("Arial", 10), bg="#EBD7CE", fg="#917F88").pack()
        
        # Форма входа
        form_frame = Frame(main_frame, bg="#EBD7CE")
        form_frame.pack(fill=X, pady=(20, 0))
        
        Label(form_frame, text="Логин", font=("Arial", 10), bg="#EBD7CE", fg="#836871", anchor="w").pack(fill=X, pady=(0, 5))
        self.login_entry = Entry(form_frame, font=("Arial", 12), bg="#CDADAB", fg="#FFFFFF", insertbackground="white", relief=FLAT)
        self.login_entry.pack(fill=X, ipady=5, padx=5, pady=5)
        
        Label(form_frame, text="Пароль", font=("Arial", 10), bg="#EBD7CE", fg="#836871", anchor="w").pack(fill=X, pady=(15, 5))
        self.password_entry = Entry(form_frame, show="•", font=("Arial", 12), bg="#CDADAB", fg="#FFFFFF", insertbackground="white", relief=FLAT)
        self.password_entry.pack(fill=X, ipady=5, padx=5, pady=5)
        
        # Кнопки
        button_frame = Frame(main_frame, bg="#EBD7CE")
        button_frame.pack(fill=X, pady=(30, 0))
        
        # Яркая кнопка входа
        Button(button_frame, text="Войти", command=self.login, 
              bg="#836871", fg="white", font=("Arial", 12, "bold"), 
              relief=FLAT, padx=20, pady=10).pack(fill=X, pady=(0, 10))
        
        # Контрастная кнопка регистрации
        Button(button_frame, text="Создать аккаунт", command=self.open_register,
              bg="#A37E84", fg="white", font=("Arial", 12), 
              relief=FLAT, padx=20, pady=10).pack(fill=X)
        
        # Подвал
        Label(main_frame, text="© 2023 Водяной | Пейте воду регулярно", 
             font=("Arial", 8), bg="#EBD7CE", fg="#917F88").pack(pady=(30, 0))

    def login(self):
        login = self.login_entry.get()
        password = self.password_entry.get()
        
        if not login or not password:
            messagebox.showwarning("Ошибка", "Введите логин и пароль")
            return
            
        if self.tracker.login_user(login, password):
            self.root.destroy()
            MainWindow(Tk(), self.tracker)
        else:
            messagebox.showerror("Ошибка", "Неверный логин или пароль")

    def open_register(self):
        register_window = Toplevel(self.root)
        RegisterWindow(register_window, self.tracker)

class RegisterWindow:
    def __init__(self, root, tracker):
        self.root = root
        self.tracker = tracker
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Регистрация")
        self.root.geometry("400x400")
        self.root.configure(bg="#EBD7CE")
        center_window(self.root, 400, 400)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#EBD7CE", padx=30, pady=30)
        main_frame.pack(expand=True, fill=BOTH)
        
        Label(main_frame, text="Создать аккаунт", font=("Arial", 20, "bold"), 
             bg="#EBD7CE", fg="#836871").pack(pady=20)
        
        # Поля формы
        form_frame = Frame(main_frame, bg="#EBD7CE")
        form_frame.pack(fill=X, pady=10)
        
        Label(form_frame, text="Логин:", bg="#EBD7CE", fg="#836871").pack(anchor="w")
        self.login_entry = Entry(form_frame, font=("Arial", 12), bg="#CDADAB")
        self.login_entry.pack(fill=X, pady=5)
        
        Label(form_frame, text="Пароль:", bg="#EBD7CE", fg="#836871").pack(anchor="w")
        self.password_entry = Entry(form_frame, show="•", font=("Arial", 12), bg="#CDADAB")
        self.password_entry.pack(fill=X, pady=5)
        
        # Кнопки
        Button(main_frame, text="Зарегистрироваться", command=self.register,
              bg="#836871", fg="white", font=("Arial", 12), 
              padx=20, pady=10).pack(pady=20)
        
        Button(main_frame, text="Отмена", command=self.root.destroy,
              bg="#A37E84", fg="white", font=("Arial", 10), 
              padx=15, pady=5).pack()

    def register(self):
        login = self.login_entry.get()
        password = self.password_entry.get()
        
        if not login or not password:
            messagebox.showwarning("Ошибка", "Заполните все поля")
            return
            
        if self.tracker.register_user(login, password):
            messagebox.showinfo("Успех", "Регистрация завершена!")
            self.root.destroy()
        else:
            messagebox.showerror("Ошибка", "Логин уже занят")

class MainWindow:
    def __init__(self, root, tracker):
        self.root = root
        self.tracker = tracker
        self.setup_window()
        self.create_widgets()
        self.update_ui()
        
    def setup_window(self):
        self.root.title("Водяной")
        self.root.geometry("800x600")
        self.root.configure(bg="#EBD7CE")
        center_window(self.root, 800, 600)
        
    def create_widgets(self):
        # Верхняя панель
        header_frame = Frame(self.root, bg="#836871", height=80)
        header_frame.pack(fill=X)
        header_frame.pack_propagate(False)
        
        Label(header_frame, text="💧 Водяной", font=("Arial", 18, "bold"), 
             bg="#836871", fg="#FFFFFF").pack(side=LEFT, padx=20)
        
        Button(header_frame, text="Выйти", command=self.quit_app, 
              bg="#A37E84", fg="white", font=("Arial", 12), relief=FLAT, padx=20,
              activebackground="#917F88", activeforeground="white").pack(side=RIGHT, padx=20)
        
        # Основное содержимое
        content_frame = Frame(self.root, bg="#EBD7CE")
        content_frame.pack(expand=True, fill=BOTH, padx=20, pady=20)
        
        # Левая панель - прогресс
        left_frame = Frame(content_frame, bg="#EBD7CE", width=300)
        left_frame.pack(side=LEFT, fill=Y)
        
        progress_frame = Frame(left_frame, bg="#CDADAB", padx=20, pady=20)
        progress_frame.pack(pady=20, fill=X)
        
        Label(progress_frame, text="Ваш прогресс", font=("Arial", 16, "bold"), 
             bg="#CDADAB", fg="#836871").pack(anchor="w", pady=(0, 20))
        
        self.progress_label = Label(progress_frame, text="0%", font=("Arial", 32, "bold"), 
                                  bg="#CDADAB", fg="#836871")
        self.progress_label.pack()
        
        self.amount_label = Label(progress_frame, text="0 / 0 мл", font=("Arial", 24), 
                                bg="#CDADAB", fg="#836871")
        self.amount_label.pack(pady=20)
        
        # Правая панель - управление
        right_frame = Frame(content_frame, bg="#EBD7CE", padx=20)
        right_frame.pack(side=RIGHT, fill=BOTH, expand=True)
        
        # Кнопки добавления воды
        buttons_frame = Frame(right_frame, bg="#EBD7CE")
        buttons_frame.pack(pady=50)
        
        Button(buttons_frame, text="+250 мл", command=lambda: self.add_water(250), 
              bg="#836871", fg="white", font=("Arial", 14), relief=FLAT, padx=20, pady=10, width=15,
              activebackground="#917F88", activeforeground="white").grid(row=0, column=0, padx=10, pady=10)
        
        Button(buttons_frame, text="+500 мл", command=lambda: self.add_water(500), 
              bg="#836871", fg="white", font=("Arial", 14), relief=FLAT, padx=20, pady=10, width=15,
              activebackground="#917F88", activeforeground="white").grid(row=0, column=1, padx=10, pady=10)
        
        # Настройки
        Button(right_frame, text="Настройки", command=self.open_settings, 
              bg="#A37E84", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#917F88", activeforeground="white").pack(fill=X, pady=30)
        
        # Статистика
        stats_frame = Frame(right_frame, bg="#CDADAB", padx=20, pady=15)
        stats_frame.pack(fill=X)
        
        Label(stats_frame, text="Статистика", font=("Arial", 12, "bold"), 
             bg="#CDADAB", fg="#836871").pack(anchor="w", pady=(0, 10))
        
        self.last_drink_label = Label(stats_frame, text="Последний прием: --:--", 
                                    font=("Arial", 10), bg="#CDADAB", fg="#836871")
        self.last_drink_label.pack(anchor="w")
        
        self.daily_average_label = Label(stats_frame, text="Среднее за день: 0 мл", 
                                       font=("Arial", 10), bg="#CDADAB", fg="#836871")
        self.daily_average_label.pack(anchor="w", pady=5)

    def add_water(self, volume):
        if self.tracker.add_water(volume):
            self.update_ui()
            messagebox.showinfo("Успех", f"Добавлено {volume} мл воды!")

    def update_ui(self):
        data = self.tracker.get_user_data()
        progress = (data['current_volume'] / data['daily_goal']) * 100 if data['daily_goal'] > 0 else 0
        
        self.progress_label.config(text=f"{int(progress)}%")
        self.amount_label.config(text=f"{data['current_volume']} / {data['daily_goal']} мл")
        
        if progress >= 100:
            self.progress_label.config(fg="#586144")
        elif progress >= 50:
            self.progress_label.config(fg="#5D4459")
        else:
            self.progress_label.config(fg="#836871")
        
        if data['last_drink_time']:
            drink_time = datetime.strptime(data['last_drink_time'], "%Y-%m-%d %H:%M:%S.%f")
            self.last_drink_label.config(text=f"Последний прием: {drink_time.strftime('%H:%M')}")

    def open_settings(self):
        SettingsWindow(Toplevel(self.root), self.tracker, self.update_ui)

    def quit_app(self):
        self.tracker.stop_notification_thread()
        self.root.quit()

class SettingsWindow:
    def __init__(self, root, tracker, callback):
        self.root = root
        self.tracker = tracker
        self.callback = callback
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Настройки")
        self.root.geometry("400x500")
        self.root.resizable(False, False)
        self.root.configure(bg="#EBD7CE")
        center_window(self.root, 400, 500)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#EBD7CE", padx=30, pady=30)
        main_frame.pack(expand=True, fill=BOTH)
        
        Label(main_frame, text="Настройки", font=("Arial", 24, "bold"), 
             bg="#EBD7CE", fg="#836871").pack(fill=X, pady=(0, 30))
        
        form_frame = Frame(main_frame, bg="#EBD7CE")
        form_frame.pack(fill=X)
        
        # Загружаем данные с гарантией наличия notifications_enabled
        data = self.tracker.get_user_data()
        
        # Цель
        goal_frame = Frame(form_frame, bg="#EBD7CE", pady=15)
        goal_frame.pack(fill=X)
        
        Label(goal_frame, text="Дневная цель (мл)", font=("Arial", 12), 
             bg="#EBD7CE", fg="#836871").pack(anchor="w", pady=(0, 5))
        
        self.goal_entry = Entry(goal_frame, font=("Arial", 14), bg="#CDADAB", fg="#FFFFFF", insertbackground="white", relief=FLAT)
        self.goal_entry.pack(fill=X, ipady=8)
        self.goal_entry.insert(0, data["daily_goal"])
        
        # Интервал напоминаний
        interval_frame = Frame(form_frame, bg="#EBD7CE", pady=15)
        interval_frame.pack(fill=X)
        
        Label(interval_frame, text="Интервал напоминаний (мин)", font=("Arial", 12), 
             bg="#EBD7CE", fg="#836871").pack(anchor="w", pady=(0, 5))
        
        self.interval_entry = Entry(interval_frame, font=("Arial", 14), bg="#CDADAB", fg="#FFFFFF", insertbackground="white", relief=FLAT)
        self.interval_entry.pack(fill=X, ipady=8)
        self.interval_entry.insert(0, data["reminder_interval"])
        
        # Включение уведомлений
        self.notifications_var = BooleanVar(value=data.get("notifications_enabled", True))
        Checkbutton(form_frame, text="Включить уведомления", variable=self.notifications_var,
                   bg="#EBD7CE", fg="#836871", selectcolor="#CDADAB", activebackground="#EBD7CE",
                   activeforeground="#836871", font=("Arial", 12)).pack(anchor="w", pady=15)
        
        # Кнопки
        button_frame = Frame(main_frame, bg="#EBD7CE", pady=30)
        button_frame.pack(fill=X)
        
        Button(button_frame, text="Сохранить", command=self.save_settings,
              bg="#836871", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#917F88", activeforeground="white").pack(fill=X)
        
        Button(button_frame, text="Отмена", command=self.root.destroy,
              bg="#A37E84", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#917F88", activeforeground="white").pack(fill=X, pady=(10, 0))

    def save_settings(self):
        try:
            goal = int(self.goal_entry.get())
            interval = int(self.interval_entry.get())
            notifications_enabled = self.notifications_var.get()
            
            if goal <= 0 or interval <= 0:
                raise ValueError("Значения должны быть положительными")
                
            if self.tracker.update_settings(goal, interval, notifications_enabled):
                messagebox.showinfo("Успех", "Настройки сохранены!")
                self.callback()
                self.root.destroy()
        except ValueError as e:
            messagebox.showerror("Ошибка", f"Некорректные данные: {str(e)}")

def center_window(root, width, height):
    """Центрирует окно на экране"""
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width - width) // 2
    y = (screen_height - height) // 2 - 50
    root.geometry(f"{width}x{height}+{x}+{y}")

def main():
    # Проверка наличия plyer для уведомлений
    try:
        from plyer import notification
    except ImportError:
        messagebox.showerror("Ошибка", 
            "Для уведомлений установите plyer: pip install plyer")
        return
    
    tracker = WaterTracker()
    root = Tk()
    AuthWindow(root, tracker)
    root.mainloop()

if __name__ == "__main__":
    main()