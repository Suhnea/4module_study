import json
import os
import time
from tkinter import *
from tkinter import messagebox, ttk
from datetime import datetime, timedelta
import threading
from plyer import notification

class TaskManager:
    def __init__(self):
        self.users_file = "users.json"
        self.tasks_file = "tasks.json"
        self.notifications_file = "notifications.json"
        self.current_user = None
        self.initialize_files()
        self.notification_thread = None
        self.running = True

    def initialize_files(self):
        """Инициализирует файлы с проверкой их валидности"""
        for file, default in [
            (self.users_file, {"users": []}),
            (self.tasks_file, {}),
            (self.notifications_file, {})
        ]:
            if not os.path.exists(file):
                with open(file, 'w') as f:
                    json.dump(default, f, indent=4)
            else:
                try:
                    with open(file, 'r') as f:
                        json.load(f)
                except json.JSONDecodeError:
                    with open(file, 'w') as f:
                        json.dump(default, f, indent=4)

    def register_user(self, login, password):
        """Регистрирует нового пользователя"""
        try:
            with open(self.users_file, 'r+') as f:
                data = json.load(f)
                
                if any(user["login"] == login for user in data["users"]):
                    return False
                    
                data["users"].append({"login": login, "password": password})
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
                
            self.init_user_data(login)
            return True
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось зарегистрироваться: {str(e)}")
            return False

    def init_user_data(self, login):
        """Инициализирует данные пользователя"""
        try:
            with open(self.tasks_file, 'r+') as f:
                data = json.load(f)
                if login not in data:
                    data[login] = {
                        "tasks": [],
                        "reminder_interval": 60,
                        "notifications_enabled": True
                    }
                    f.seek(0)
                    json.dump(data, f, indent=4)
                    f.truncate()
        except Exception as e:
            print(f"Ошибка инициализации данных: {str(e)}")

    def login_user(self, login, password):
        """Аутентификация пользователя"""
        try:
            with open(self.users_file, 'r') as f:
                data = json.load(f)
                for user in data["users"]:
                    if user["login"] == login and user["password"] == password:
                        self.current_user = login
                        self.start_notification_thread()
                        return True
            return False
        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка входа: {str(e)}")
            return False

    def add_task(self, title, description, priority, due_date):
        """Добавляет новую задачу"""
        try:
            with open(self.tasks_file, 'r+') as f:
                data = json.load(f)
                user_data = data.setdefault(self.current_user, {
                    "tasks": [],
                    "reminder_interval": 60,
                    "notifications_enabled": True
                })
                
                new_task = {
                    "id": len(user_data["tasks"]) + 1,
                    "title": title,
                    "description": description,
                    "priority": priority,
                    "due_date": due_date,
                    "completed": False,
                    "created_at": str(datetime.now())
                }
                
                user_data["tasks"].append(new_task)
                
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
            
            return True
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось добавить задачу: {str(e)}")
            return False

    def get_user_data(self):
        """Получает данные пользователя"""
        try:
            with open(self.tasks_file, 'r') as f:
                data = json.load(f)
                user_data = data.get(self.current_user, {
                    "tasks": [],
                    "reminder_interval": 60,
                    "notifications_enabled": True
                })
                return user_data
        except Exception:
            return {
                "tasks": [],
                "reminder_interval": 60,
                "notifications_enabled": True
            }

    def update_task(self, task_id, completed=None, title=None, description=None, priority=None, due_date=None):
        """Обновляет задачу"""
        try:
            with open(self.tasks_file, 'r+') as f:
                data = json.load(f)
                user_data = data.setdefault(self.current_user, {
                    "tasks": [],
                    "reminder_interval": 60,
                    "notifications_enabled": True
                })
                
                for task in user_data["tasks"]:
                    if task["id"] == task_id:
                        if completed is not None:
                            task["completed"] = completed
                        if title is not None:
                            task["title"] = title
                        if description is not None:
                            task["description"] = description
                        if priority is not None:
                            task["priority"] = priority
                        if due_date is not None:
                            task["due_date"] = due_date
                        break
                
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
            
            return True
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось обновить задачу: {str(e)}")
            return False

    def delete_task(self, task_id):
        """Удаляет задачу"""
        try:
            with open(self.tasks_file, 'r+') as f:
                data = json.load(f)
                user_data = data.setdefault(self.current_user, {
                    "tasks": [],
                    "reminder_interval": 60,
                    "notifications_enabled": True
                })
                
                user_data["tasks"] = [task for task in user_data["tasks"] if task["id"] != task_id]
                
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
            
            return True
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось удалить задачу: {str(e)}")
            return False

    def update_settings(self, reminder_interval, notifications_enabled):
        """Обновляет настройки пользователя"""
        try:
            with open(self.tasks_file, 'r+') as f:
                data = json.load(f)
                user_data = data.setdefault(self.current_user, {
                    "tasks": [],
                    "reminder_interval": 60,
                    "notifications_enabled": True
                })
                
                user_data["reminder_interval"] = reminder_interval
                user_data["notifications_enabled"] = notifications_enabled
                
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
            
            self.start_notification_thread()
            return True
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось обновить настройки: {str(e)}")
            return False

    def check_notifications(self):
        """Проверяет необходимость показа уведомлений о задачах"""
        while self.running:
            try:
                data = self.get_user_data()
                
                if not data.get("notifications_enabled", True):
                    time.sleep(60)
                    continue
                
                # Проверяем, когда было последнее уведомление
                last_notified = None
                if os.path.exists(self.notifications_file):
                    with open(self.notifications_file, 'r') as f:
                        notifications_data = json.load(f)
                        last_notified_str = notifications_data.get(self.current_user)
                        if last_notified_str:
                            last_notified = datetime.strptime(last_notified_str, "%Y-%m-%d %H:%M:%S.%f")
                
                interval_minutes = data.get("reminder_interval", 60)
                if last_notified and (datetime.now() - last_notified) < timedelta(minutes=interval_minutes):
                    time.sleep(60)
                    continue
                
                # Проверяем задачи с приближающимся сроком
                urgent_tasks = []
                for task in data.get("tasks", []):
                    if not task["completed"] and task["due_date"]:
                        due_date = datetime.strptime(task["due_date"], "%Y-%m-%d")
                        if (due_date - datetime.now()).days <= 1:
                            urgent_tasks.append(task["title"])
                
                if urgent_tasks:
                    notification.notify(
                        title="День студента - Напоминание",
                        message=f"Срочные задачи: {', '.join(urgent_tasks)}",
                        app_name="День студента 25",
                        timeout=10
                    )
                    
                    # Обновляем время последнего уведомления
                    self.save_last_notification_time()
                
                time.sleep(60)
            except Exception as e:
                print(f"Ошибка в потоке уведомлений: {str(e)}")
                time.sleep(60)

    def save_last_notification_time(self):
        """Сохраняет время последнего уведомления"""
        try:
            with open(self.notifications_file, 'r+') as f:
                data = json.load(f)
                data[self.current_user] = str(datetime.now())
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
        except Exception as e:
            print(f"Ошибка сохранения времени уведомления: {str(e)}")

    def start_notification_thread(self):
        """Запускает поток для проверки уведомлений"""
        if self.notification_thread and self.notification_thread.is_alive():
            self.running = False
            self.notification_thread.join()
        
        self.running = True
        self.notification_thread = threading.Thread(target=self.check_notifications, daemon=True)
        self.notification_thread.start()

    def stop_notification_thread(self):
        """Останавливает поток уведомлений"""
        self.running = False
        if self.notification_thread and self.notification_thread.is_alive():
            self.notification_thread.join()

class AuthWindow:
    def __init__(self, root, manager):
        self.root = root
        self.manager = manager
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("День студента 25 • Авторизация")
        self.root.geometry("400x600")
        self.root.resizable(False, False)
        self.root.configure(bg="#D4E6F1")
        center_window(self.root, 400, 600)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#D4E6F1", padx=30, pady=40)
        main_frame.pack(expand=True, fill=BOTH)
        
        # Логотип
        logo_frame = Frame(main_frame, bg="#D4E6F1")
        logo_frame.pack(pady=(0, 30))
        
        Label(logo_frame, text="📚", font=("Arial", 48), bg="#D4E6F1", fg="#3A5F8D").pack()
        Label(logo_frame, text="День студента 25", font=("Arial", 20, "bold"), bg="#D4E6F1", fg="#3A5F8D").pack(pady=(10, 0))
        Label(logo_frame, text="Управление задачами и расписанием", font=("Arial", 10), bg="#D4E6F1", fg="#5D7BA5").pack()
        
        # Форма входа
        form_frame = Frame(main_frame, bg="#D4E6F1")
        form_frame.pack(fill=X, pady=(20, 0))
        
        Label(form_frame, text="Логин", font=("Arial", 10), bg="#D4E6F1", fg="#3A5F8D", anchor="w").pack(fill=X, pady=(0, 5))
        self.login_entry = Entry(form_frame, font=("Arial", 12), bg="#A8C4E0", fg="#FFFFFF", insertbackground="white", relief=FLAT)
        self.login_entry.pack(fill=X, ipady=5, padx=5, pady=5)
        
        Label(form_frame, text="Пароль", font=("Arial", 10), bg="#D4E6F1", fg="#3A5F8D", anchor="w").pack(fill=X, pady=(15, 5))
        self.password_entry = Entry(form_frame, show="•", font=("Arial", 12), bg="#A8C4E0", fg="#FFFFFF", insertbackground="white", relief=FLAT)
        self.password_entry.pack(fill=X, ipady=5, padx=5, pady=5)
        
        # Кнопки
        button_frame = Frame(main_frame, bg="#D4E6F1")
        button_frame.pack(fill=X, pady=(30, 0))
        
        Button(button_frame, text="Войти", command=self.login, 
              bg="#3A5F8D", fg="white", font=("Arial", 12, "bold"), 
              relief=FLAT, padx=20, pady=10).pack(fill=X, pady=(0, 10))
        
        Button(button_frame, text="Создать аккаунт", command=self.open_register,
              bg="#5D7BA5", fg="white", font=("Arial", 12), 
              relief=FLAT, padx=20, pady=10).pack(fill=X)
        
        # Подвал
        Label(main_frame, text="© 2023 День студента 25 | Успешной учебы!", 
             font=("Arial", 8), bg="#D4E6F1", fg="#5D7BA5").pack(pady=(30, 0))

    def login(self):
        login = self.login_entry.get()
        password = self.password_entry.get()
        
        if not login or not password:
            messagebox.showwarning("Ошибка", "Введите логин и пароль")
            return
            
        if self.manager.login_user(login, password):
            self.root.destroy()
            MainWindow(Tk(), self.manager)
        else:
            messagebox.showerror("Ошибка", "Неверный логин или пароль")

    def open_register(self):
        register_window = Toplevel(self.root)
        RegisterWindow(register_window, self.manager)

class RegisterWindow:
    def __init__(self, root, manager):
        self.root = root
        self.manager = manager
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Регистрация")
        self.root.geometry("400x400")
        self.root.configure(bg="#D4E6F1")
        center_window(self.root, 400, 400)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#D4E6F1", padx=30, pady=30)
        main_frame.pack(expand=True, fill=BOTH)
        
        Label(main_frame, text="Создать аккаунт", font=("Arial", 20, "bold"), 
             bg="#D4E6F1", fg="#3A5F8D").pack(pady=20)
        
        # Поля формы
        form_frame = Frame(main_frame, bg="#D4E6F1")
        form_frame.pack(fill=X, pady=10)
        
        Label(form_frame, text="Логин:", bg="#D4E6F1", fg="#3A5F8D").pack(anchor="w")
        self.login_entry = Entry(form_frame, font=("Arial", 12), bg="#A8C4E0")
        self.login_entry.pack(fill=X, pady=5)
        
        Label(form_frame, text="Пароль:", bg="#D4E6F1", fg="#3A5F8D").pack(anchor="w")
        self.password_entry = Entry(form_frame, show="•", font=("Arial", 12), bg="#A8C4E0")
        self.password_entry.pack(fill=X, pady=5)
        
        # Кнопки
        Button(main_frame, text="Зарегистрироваться", command=self.register,
              bg="#3A5F8D", fg="white", font=("Arial", 12), 
              padx=20, pady=10).pack(pady=20)
        
        Button(main_frame, text="Отмена", command=self.root.destroy,
              bg="#5D7BA5", fg="white", font=("Arial", 10), 
              padx=15, pady=5).pack()

    def register(self):
        login = self.login_entry.get()
        password = self.password_entry.get()
        
        if not login or not password:
            messagebox.showwarning("Ошибка", "Заполните все поля")
            return
            
        if self.manager.register_user(login, password):
            messagebox.showinfo("Успех", "Регистрация завершена!")
            self.root.destroy()
        else:
            messagebox.showerror("Ошибка", "Логин уже занят")

class MainWindow:
    def __init__(self, root, manager):
        self.root = root
        self.manager = manager
        self.setup_window()
        self.create_widgets()
        self.load_tasks()
        
    def setup_window(self):
        self.root.title("День студента 25")
        self.root.geometry("1000x700")
        self.root.configure(bg="#D4E6F1")
        center_window(self.root, 1000, 700)
        
    def create_widgets(self):
        # Верхняя панель
        header_frame = Frame(self.root, bg="#3A5F8D", height=80)
        header_frame.pack(fill=X)
        header_frame.pack_propagate(False)
        
        Label(header_frame, text="📚 День студента 25", font=("Arial", 18, "bold"), 
             bg="#3A5F8D", fg="#FFFFFF").pack(side=LEFT, padx=20)
        
        Button(header_frame, text="Выйти", command=self.quit_app, 
              bg="#5D7BA5", fg="white", font=("Arial", 12), relief=FLAT, padx=20,
              activebackground="#4A6B9D", activeforeground="white").pack(side=RIGHT, padx=20)
        
        # Основное содержимое
        content_frame = Frame(self.root, bg="#D4E6F1")
        content_frame.pack(expand=True, fill=BOTH, padx=20, pady=20)
        
        # Левая панель - добавление задачи
        left_frame = Frame(content_frame, bg="#D4E6F1", width=300)
        left_frame.pack(side=LEFT, fill=Y)
        
        add_task_frame = Frame(left_frame, bg="#A8C4E0", padx=20, pady=20)
        add_task_frame.pack(pady=20, fill=X)
        
        Label(add_task_frame, text="Добавить задачу", font=("Arial", 16, "bold"), 
             bg="#A8C4E0", fg="#3A5F8D").pack(anchor="w", pady=(0, 20))
        
        # Поля для добавления задачи
        Label(add_task_frame, text="Название", font=("Arial", 10), bg="#A8C4E0", fg="#3A5F8D").pack(anchor="w")
        self.title_entry = Entry(add_task_frame, font=("Arial", 12), bg="#D4E6F1", relief=FLAT)
        self.title_entry.pack(fill=X, pady=5)
        
        Label(add_task_frame, text="Описание", font=("Arial", 10), bg="#A8C4E0", fg="#3A5F8D").pack(anchor="w", pady=(10, 0))
        self.desc_entry = Text(add_task_frame, font=("Arial", 12), bg="#D4E6F1", height=4, relief=FLAT)
        self.desc_entry.pack(fill=X, pady=5)
        
        Label(add_task_frame, text="Приоритет", font=("Arial", 10), bg="#A8C4E0", fg="#3A5F8D").pack(anchor="w", pady=(10, 0))
        self.priority_var = StringVar(value="Средний")
        priority_menu = OptionMenu(add_task_frame, self.priority_var, "Низкий", "Средний", "Высокий")
        priority_menu.config(bg="#D4E6F1", fg="#3A5F8D", relief=FLAT, font=("Arial", 12))
        priority_menu.pack(fill=X, pady=5)
        
        Label(add_task_frame, text="Срок выполнения (ГГГГ-ММ-ДД)", font=("Arial", 10), bg="#A8C4E0", fg="#3A5F8D").pack(anchor="w", pady=(10, 0))
        self.due_entry = Entry(add_task_frame, font=("Arial", 12), bg="#D4E6F1", relief=FLAT)
        self.due_entry.pack(fill=X, pady=5)
        
        Button(add_task_frame, text="Добавить", command=self.add_task,
              bg="#3A5F8D", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#4A6B9D", activeforeground="white").pack(fill=X, pady=(20, 0))
        
        # Правая панель - список задач
        right_frame = Frame(content_frame, bg="#D4E6F1", padx=20)
        right_frame.pack(side=RIGHT, fill=BOTH, expand=True)
        
        # Фильтры и поиск
        filter_frame = Frame(right_frame, bg="#D4E6F1")
        filter_frame.pack(fill=X, pady=(0, 20))
        
        Label(filter_frame, text="Фильтры:", bg="#D4E6F1", fg="#3A5F8D").pack(side=LEFT)
        
        self.filter_var = StringVar(value="Все")
        Radiobutton(filter_frame, text="Все", variable=self.filter_var, value="Все", 
                   bg="#D4E6F1", command=self.load_tasks).pack(side=LEFT, padx=5)
        Radiobutton(filter_frame, text="Активные", variable=self.filter_var, value="Активные", 
                   bg="#D4E6F1", command=self.load_tasks).pack(side=LEFT, padx=5)
        Radiobutton(filter_frame, text="Завершенные", variable=self.filter_var, value="Завершенные", 
                   bg="#D4E6F1", command=self.load_tasks).pack(side=LEFT, padx=5)
        
        # Таблица задач
        self.tasks_tree = ttk.Treeview(right_frame, columns=("title", "priority", "due_date", "completed"), show="headings", height=15)
        self.tasks_tree.heading("title", text="Название")
        self.tasks_tree.heading("priority", text="Приоритет")
        self.tasks_tree.heading("due_date", text="Срок")
        self.tasks_tree.heading("completed", text="Статус")
        
        self.tasks_tree.column("title", width=200)
        self.tasks_tree.column("priority", width=100)
        self.tasks_tree.column("due_date", width=100)
        self.tasks_tree.column("completed", width=100)
        
        self.tasks_tree.pack(fill=BOTH, expand=True)
        
        # Кнопки управления задачами
        button_frame = Frame(right_frame, bg="#D4E6F1")
        button_frame.pack(fill=X, pady=(20, 0))
        
        Button(button_frame, text="Пометить как выполненное", command=self.mark_completed,
              bg="#3A5F8D", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#4A6B9D", activeforeground="white").pack(side=LEFT, padx=5)
        
        Button(button_frame, text="Редактировать", command=self.edit_task,
              bg="#5D7BA5", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#4A6B9D", activeforeground="white").pack(side=LEFT, padx=5)
        
        Button(button_frame, text="Удалить", command=self.delete_task,
              bg="#5D7BA5", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#4A6B9D", activeforeground="white").pack(side=LEFT, padx=5)
        
        # Настройки
        Button(right_frame, text="Настройки", command=self.open_settings, 
              bg="#5D7BA5", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#4A6B9D", activeforeground="white").pack(fill=X, pady=(20, 0))

    def add_task(self):
        title = self.title_entry.get()
        description = self.desc_entry.get("1.0", END).strip()
        priority = self.priority_var.get()
        due_date = self.due_entry.get()
        
        if not title:
            messagebox.showwarning("Ошибка", "Введите название задачи")
            return
            
        if self.manager.add_task(title, description, priority, due_date):
            self.title_entry.delete(0, END)
            self.desc_entry.delete("1.0", END)
            self.due_entry.delete(0, END)
            self.load_tasks()
            messagebox.showinfo("Успех", "Задача добавлена!")
        else:
            messagebox.showerror("Ошибка", "Не удалось добавить задачу")

    def load_tasks(self):
        """Загружает задачи в таблицу с учетом фильтра"""
        self.tasks_tree.delete(*self.tasks_tree.get_children())
        
        data = self.manager.get_user_data()
        tasks = data.get("tasks", [])
        
        filter_type = self.filter_var.get()
        if filter_type == "Активные":
            tasks = [task for task in tasks if not task["completed"]]
        elif filter_type == "Завершенные":
            tasks = [task for task in tasks if task["completed"]]
        
        for task in tasks:
            status = "✅" if task["completed"] else "❌"
            self.tasks_tree.insert("", END, values=(
                task["title"],
                task["priority"],
                task["due_date"] if task["due_date"] else "-",
                status
            ), iid=task["id"])

    def get_selected_task_id(self):
        """Возвращает ID выбранной задачи"""
        selection = self.tasks_tree.selection()
        if not selection:
            messagebox.showwarning("Ошибка", "Выберите задачу")
            return None
        return int(selection[0])

    def mark_completed(self):
        task_id = self.get_selected_task_id()
        if task_id is None:
            return
            
        if self.manager.update_task(task_id, completed=True):
            self.load_tasks()
            messagebox.showinfo("Успех", "Задача помечена как выполненная")
        else:
            messagebox.showerror("Ошибка", "Не удалось обновить задачу")

    def edit_task(self):
        task_id = self.get_selected_task_id()
        if task_id is None:
            return
            
        data = self.manager.get_user_data()
        task = next((t for t in data["tasks"] if t["id"] == task_id), None)
        
        if not task:
            messagebox.showerror("Ошибка", "Задача не найдена")
            return
            
        edit_window = Toplevel(self.root)
        EditTaskWindow(edit_window, self.manager, task, self.load_tasks)

    def delete_task(self):
        task_id = self.get_selected_task_id()
        if task_id is None:
            return
            
        if messagebox.askyesno("Подтверждение", "Удалить выбранную задачу?"):
            if self.manager.delete_task(task_id):
                self.load_tasks()
                messagebox.showinfo("Успех", "Задача удалена")
            else:
                messagebox.showerror("Ошибка", "Не удалось удалить задачу")

    def open_settings(self):
        SettingsWindow(Toplevel(self.root), self.manager, self.load_tasks)

    def quit_app(self):
        self.manager.stop_notification_thread()
        self.root.quit()

class EditTaskWindow:
    def __init__(self, root, manager, task, callback):
        self.root = root
        self.manager = manager
        self.task = task
        self.callback = callback
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Редактирование задачи")
        self.root.geometry("400x500")
        self.root.resizable(False, False)
        self.root.configure(bg="#D4E6F1")
        center_window(self.root, 400, 500)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#D4E6F1", padx=30, pady=30)
        main_frame.pack(expand=True, fill=BOTH)
        
        Label(main_frame, text="Редактирование задачи", font=("Arial", 20, "bold"), 
             bg="#D4E6F1", fg="#3A5F8D").pack(fill=X, pady=(0, 30))
        
        form_frame = Frame(main_frame, bg="#D4E6F1")
        form_frame.pack(fill=X)
        
        # Поля для редактирования
        Label(form_frame, text="Название", font=("Arial", 10), bg="#D4E6F1", fg="#3A5F8D").pack(anchor="w")
        self.title_entry = Entry(form_frame, font=("Arial", 12), bg="#A8C4E0", fg="#FFFFFF", insertbackground="white", relief=FLAT)
        self.title_entry.pack(fill=X, ipady=5, pady=5)
        self.title_entry.insert(0, self.task["title"])
        
        Label(form_frame, text="Описание", font=("Arial", 10), bg="#D4E6F1", fg="#3A5F8D").pack(anchor="w", pady=(10, 0))
        self.desc_entry = Text(form_frame, font=("Arial", 12), bg="#A8C4E0", fg="#FFFFFF", height=5, relief=FLAT)
        self.desc_entry.pack(fill=X, pady=5)
        self.desc_entry.insert("1.0", self.task["description"])
        
        Label(form_frame, text="Приоритет", font=("Arial", 10), bg="#D4E6F1", fg="#3A5F8D").pack(anchor="w", pady=(10, 0))
        self.priority_var = StringVar(value=self.task["priority"])
        priority_menu = OptionMenu(form_frame, self.priority_var, "Низкий", "Средний", "Высокий")
        priority_menu.config(bg="#A8C4E0", fg="#FFFFFF", relief=FLAT, font=("Arial", 12))
        priority_menu.pack(fill=X, pady=5)
        
        Label(form_frame, text="Срок выполнения (ГГГГ-ММ-ДД)", font=("Arial", 10), bg="#D4E6F1", fg="#3A5F8D").pack(anchor="w", pady=(10, 0))
        self.due_entry = Entry(form_frame, font=("Arial", 12), bg="#A8C4E0", fg="#FFFFFF", insertbackground="white", relief=FLAT)
        self.due_entry.pack(fill=X, ipady=5, pady=5)
        self.due_entry.insert(0, self.task["due_date"] if self.task["due_date"] else "")
        
        # Статус выполнения
        self.completed_var = BooleanVar(value=self.task["completed"])
        Checkbutton(form_frame, text="Завершено", variable=self.completed_var,
                   bg="#D4E6F1", fg="#3A5F8D", selectcolor="#A8C4E0", activebackground="#D4E6F1",
                   activeforeground="#3A5F8D", font=("Arial", 12)).pack(anchor="w", pady=15)
        
        # Кнопки
        button_frame = Frame(main_frame, bg="#D4E6F1", pady=20)
        button_frame.pack(fill=X)
        
        Button(button_frame, text="Сохранить", command=self.save_task,
              bg="#3A5F8D", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#4A6B9D", activeforeground="white").pack(fill=X)
        
        Button(button_frame, text="Отмена", command=self.root.destroy,
              bg="#5D7BA5", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#4A6B9D", activeforeground="white").pack(fill=X, pady=(10, 0))

    def save_task(self):
        title = self.title_entry.get()
        description = self.desc_entry.get("1.0", END).strip()
        priority = self.priority_var.get()
        due_date = self.due_entry.get()
        completed = self.completed_var.get()
        
        if not title:
            messagebox.showwarning("Ошибка", "Введите название задачи")
            return
            
        if self.manager.update_task(
            self.task["id"],
            title=title,
            description=description,
            priority=priority,
            due_date=due_date,
            completed=completed
        ):
            messagebox.showinfo("Успех", "Задача обновлена!")
            self.callback()
            self.root.destroy()
        else:
            messagebox.showerror("Ошибка", "Не удалось обновить задачу")

class SettingsWindow:
    def __init__(self, root, manager, callback):
        self.root = root
        self.manager = manager
        self.callback = callback
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Настройки")
        self.root.geometry("400x400")
        self.root.resizable(False, False)
        self.root.configure(bg="#D4E6F1")
        center_window(self.root, 400, 400)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#D4E6F1", padx=30, pady=30)
        main_frame.pack(expand=True, fill=BOTH)
        
        Label(main_frame, text="Настройки", font=("Arial", 24, "bold"), 
             bg="#D4E6F1", fg="#3A5F8D").pack(fill=X, pady=(0, 30))
        
        form_frame = Frame(main_frame, bg="#D4E6F1")
        form_frame.pack(fill=X)
        
        # Загружаем данные
        data = self.manager.get_user_data()
        
        # Интервал напоминаний
        interval_frame = Frame(form_frame, bg="#D4E6F1", pady=15)
        interval_frame.pack(fill=X)
        
        Label(interval_frame, text="Интервал напоминаний (мин)", font=("Arial", 12), 
             bg="#D4E6F1", fg="#3A5F8D").pack(anchor="w", pady=(0, 5))
        
        self.interval_entry = Entry(interval_frame, font=("Arial", 14), bg="#A8C4E0", fg="#FFFFFF", insertbackground="white", relief=FLAT)
        self.interval_entry.pack(fill=X, ipady=8)
        self.interval_entry.insert(0, data["reminder_interval"])
        
        # Включение уведомлений
        self.notifications_var = BooleanVar(value=data.get("notifications_enabled", True))
        Checkbutton(form_frame, text="Включить уведомления", variable=self.notifications_var,
                   bg="#D4E6F1", fg="#3A5F8D", selectcolor="#A8C4E0", activebackground="#D4E6F1",
                   activeforeground="#3A5F8D", font=("Arial", 12)).pack(anchor="w", pady=15)
        
        # Кнопки
        button_frame = Frame(main_frame, bg="#D4E6F1", pady=20)
        button_frame.pack(fill=X)
        
        Button(button_frame, text="Сохранить", command=self.save_settings,
              bg="#3A5F8D", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#4A6B9D", activeforeground="white").pack(fill=X)
        
        Button(button_frame, text="Отмена", command=self.root.destroy,
              bg="#5D7BA5", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#4A6B9D", activeforeground="white").pack(fill=X, pady=(10, 0))

    def save_settings(self):
        try:
            interval = int(self.interval_entry.get())
            notifications_enabled = self.notifications_var.get()
            
            if interval <= 0:
                raise ValueError("Интервал должен быть положительным числом")
                
            if self.manager.update_settings(interval, notifications_enabled):
                messagebox.showinfo("Успех", "Настройки сохранены!")
                self.callback()
                self.root.destroy()
        except ValueError as e:
            messagebox.showerror("Ошибка", f"Некорректные данные: {str(e)}")

def center_window(root, width, height):
    """Центрирует окно на экране"""
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width - width) // 2
    y = (screen_height - height) // 2 - 50
    root.geometry(f"{width}x{height}+{x}+{y}")

def main():
    # Проверка наличия plyer для уведомлений
    try:
        from plyer import notification
    except ImportError:
        messagebox.showerror("Ошибка", 
            "Для уведомлений установите plyer: pip install plyer")
        return
    
    manager = TaskManager()
    root = Tk()
    AuthWindow(root, manager)
    root.mainloop()

if __name__ == "__main__":
    main()