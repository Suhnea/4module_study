import json
import os
from tkinter import *
from tkinter import ttk, messagebox
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def center_window(root, width, height):
    """Центрирует окно на экране"""
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width - width) // 2
    y = (screen_height - height) // 2 - 50
    root.geometry(f"{width}x{height}+{x}+{y}")

class FinanceTracker:
    def __init__(self):
        self.users_file = "users.json"
        self.categories_file = "categories.json"
        self.current_user = None
        self.colors = {
            'light': {
                'bg': '#D4D4CE',
                'header': '#6B7B62',
                'frame': '#AEB6A5',
                'button': '#8E9B83',
                'button_active': '#6B7B62',
                'text': '#424C3B',
                'text_light': '#6B7B62',
                'entry': '#AEB6A5',
                'error': '#A44C4C',
                'tree_bg': '#FFFFFF',
                'tree_fg': '#000000'
            },
            'dark': {
                'bg': '#424C3B',
                'header': '#2D3328',
                'frame': '#5A6650',
                'button': '#6B7B62',
                'button_active': '#8E9B83',
                'text': '#D4D4CE',
                'text_light': '#AEB6A5',
                'entry': '#5A6650',
                'error': '#C45C5C',
                'tree_bg': '#2D3328',
                'tree_fg': '#D4D4CE'
            }
        }
        self.initialize_files()

    def initialize_files(self):
        """Инициализирует файлы с проверкой их валидности"""
        if not os.path.exists("data"):
            os.makedirs("data")
            
        for file, default in [
            (os.path.join("data", self.users_file), {"users": []}),
            (os.path.join("data", self.categories_file), {
                "income": ["Зарплата", "Премия", "Дивиденды", "Подарки", "Фриланс"],
                "expense": ["Еда", "Транспорт", "Жилье", "Развлечения", "Одежда", "Здоровье"]
            })
        ]:
            if not os.path.exists(file):
                with open(file, 'w', encoding='utf-8') as f:
                    json.dump(default, f, ensure_ascii=False, indent=4)

    def register_user(self, login, password):
        """Регистрирует нового пользователя"""
        try:
            users_path = os.path.join("data", self.users_file)
            data = {"users": []}
            if os.path.exists(users_path):
                with open(users_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            
            if any(user["login"] == login for user in data["users"]):
                return False
                
            data["users"].append({"login": login, "password": password})
            
            with open(users_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
                
            self.init_user_data(login)
            return True
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось зарегистрироваться: {str(e)}")
            return False

    def init_user_data(self, login):
        """Инициализирует данные пользователя"""
        user_data_file = os.path.join("data", f"user_{login}_data.json")
        if not os.path.exists(user_data_file):
            with open(user_data_file, 'w', encoding='utf-8') as f:
                json.dump({
                    "transactions": [],
                    "balance": 0,
                    "dark_mode": False
                }, f, ensure_ascii=False, indent=4)

    def login_user(self, login, password):
        """Аутентификация пользователя"""
        try:
            users_path = os.path.join("data", self.users_file)
            if not os.path.exists(users_path):
                return False
                
            with open(users_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for user in data["users"]:
                    if user["login"] == login and user["password"] == password:
                        self.current_user = login
                        return True
            return False
        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка входа: {str(e)}")
            return False

    def get_user_data(self):
        """Получает данные пользователя"""
        if not self.current_user:
            return {"transactions": [], "balance": 0, "dark_mode": False}
            
        user_data_file = os.path.join("data", f"user_{self.current_user}_data.json")
        try:
            with open(user_data_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                # Убедимся, что dark_mode есть в данных
                if 'dark_mode' not in data:
                    data['dark_mode'] = False
                return data
        except (FileNotFoundError, json.JSONDecodeError):
            return {"transactions": [], "balance": 0, "dark_mode": False}

    def save_user_data(self, data):
        """Сохраняет данные пользователя"""
        if not self.current_user:
            return
            
        user_data_file = os.path.join("data", f"user_{self.current_user}_data.json")
        with open(user_data_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

    def get_categories(self):
        """Получает категории доходов/расходов"""
        categories_path = os.path.join("data", self.categories_file)
        try:
            with open(categories_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {
                "income": ["Зарплата", "Премия", "Дивиденды", "Подарки", "Фриланс"],
                "expense": ["Еда", "Транспорт", "Жилье", "Развлечения", "Одежда", "Здоровье"]
            }

    def save_categories(self, categories):
        """Сохраняет категории"""
        categories_path = os.path.join("data", self.categories_file)
        with open(categories_path, 'w', encoding='utf-8') as f:
            json.dump(categories, f, ensure_ascii=False, indent=4)

class AuthWindow:
    def __init__(self, root, tracker):
        self.root = root
        self.tracker = tracker
        self.colors = self.tracker.colors['light']
        self.setup_window()
        self.create_widgets()
        self.root.mainloop()
        
    def setup_window(self):
        self.root.title("Копеечка • Авторизация")
        self.root.geometry("400x600")
        self.root.resizable(False, False)
        self.root.configure(bg=self.colors['bg'])
        center_window(self.root, 400, 600)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg=self.colors['bg'], padx=30, pady=40)
        main_frame.pack(expand=True, fill=BOTH)
        
        logo_frame = Frame(main_frame, bg=self.colors['bg'])
        logo_frame.pack(pady=(0, 30))
        
        Label(logo_frame, text="💰", font=("Arial", 48), bg=self.colors['bg'], fg=self.colors['text']).pack()
        Label(logo_frame, text="Копеечка", font=("Arial", 24, "bold"), bg=self.colors['bg'], fg=self.colors['text']).pack(pady=(10, 0))
        Label(logo_frame, text="Учет личных финансов", font=("Arial", 10), bg=self.colors['bg'], fg=self.colors['text_light']).pack()
        
        form_frame = Frame(main_frame, bg=self.colors['bg'])
        form_frame.pack(fill=X, pady=(20, 0))
        
        Label(form_frame, text="Логин", font=("Arial", 10), bg=self.colors['bg'], fg=self.colors['text'], anchor="w").pack(fill=X, pady=(0, 5))
        self.login_entry = Entry(form_frame, font=("Arial", 12), bg=self.colors['entry'], fg=self.colors['text'], 
                               insertbackground="white", relief=FLAT)
        self.login_entry.pack(fill=X, ipady=5, padx=5, pady=5)
        
        Label(form_frame, text="Пароль", font=("Arial", 10), bg=self.colors['bg'], fg=self.colors['text'], anchor="w").pack(fill=X, pady=(15, 5))
        self.password_entry = Entry(form_frame, show="•", font=("Arial", 12), bg=self.colors['entry'], fg=self.colors['text'], 
                                  insertbackground="white", relief=FLAT)
        self.password_entry.pack(fill=X, ipady=5, padx=5, pady=5)
        
        button_frame = Frame(main_frame, bg=self.colors['bg'])
        button_frame.pack(fill=X, pady=(30, 0))
        
        Button(button_frame, text="Войти", command=self.login, 
              bg=self.colors['button'], fg="white", font=("Arial", 12, "bold"), 
              relief=FLAT, padx=20, pady=10, activebackground=self.colors['button_active']).pack(fill=X, pady=(0, 10))
        
        Button(button_frame, text="Создать аккаунт", command=self.open_register,
              bg=self.colors['button'], fg="white", font=("Arial", 12), 
              relief=FLAT, padx=20, pady=10, activebackground=self.colors['button_active']).pack(fill=X)
        
        Label(main_frame, text="© 2023 Копеечка | Контроль финансов", 
             font=("Arial", 8), bg=self.colors['bg'], fg=self.colors['text_light']).pack(pady=(30, 0))

    def login(self):
        login = self.login_entry.get()
        password = self.password_entry.get()
        
        if not login or not password:
            messagebox.showwarning("Ошибка", "Введите логин и пароль")
            return
            
        if len(login) < 3:
            messagebox.showwarning("Ошибка", "Логин должен содержать минимум 3 символа")
            return
            
        if len(password) < 4:
            messagebox.showwarning("Ошибка", "Пароль должен содержать минимум 4 символа")
            return
            
        if self.tracker.login_user(login, password):
            self.root.destroy()
            root = Tk()
            user_data = self.tracker.get_user_data()
            if user_data.get('dark_mode', False):
                root.tk_setPalette(background=self.tracker.colors['dark']['bg'])
            MainWindow(root, self.tracker)
        else:
            messagebox.showerror("Ошибка", "Неверный логин или пароль")

    def open_register(self):
        register_window = Toplevel(self.root)
        RegisterWindow(register_window, self.tracker)

class RegisterWindow:
    def __init__(self, root, tracker):
        self.root = root
        self.tracker = tracker
        self.colors = self.tracker.colors['light']
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Регистрация")
        self.root.geometry("400x400")
        self.root.resizable(False, False)
        self.root.configure(bg=self.colors['bg'])
        center_window(self.root, 400, 400)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg=self.colors['bg'], padx=30, pady=30)
        main_frame.pack(expand=True, fill=BOTH)
        
        Label(main_frame, text="Создать аккаунт", font=("Arial", 20, "bold"), 
             bg=self.colors['bg'], fg=self.colors['text']).pack(pady=20)
        
        form_frame = Frame(main_frame, bg=self.colors['bg'])
        form_frame.pack(fill=X, pady=10)
        
        Label(form_frame, text="Логин:", bg=self.colors['bg'], fg=self.colors['text']).pack(anchor="w")
        self.login_entry = Entry(form_frame, font=("Arial", 12), bg=self.colors['entry'], fg=self.colors['text'],
                               insertbackground="white")
        self.login_entry.pack(fill=X, pady=5)
        
        Label(form_frame, text="Пароль:", bg=self.colors['bg'], fg=self.colors['text']).pack(anchor="w")
        self.password_entry = Entry(form_frame, show="•", font=("Arial", 12), bg=self.colors['entry'], fg=self.colors['text'],
                                  insertbackground="white")
        self.password_entry.pack(fill=X, pady=5)
        
        Button(main_frame, text="Зарегистрироваться", command=self.register,
              bg=self.colors['button'], fg="white", font=("Arial", 12), 
              padx=20, pady=10, activebackground=self.colors['button_active']).pack(pady=20)
        
        Button(main_frame, text="Отмена", command=self.root.destroy,
              bg=self.colors['button'], fg="white", font=("Arial", 10), 
              padx=15, pady=5, activebackground=self.colors['button_active']).pack()

    def register(self):
        login = self.login_entry.get()
        password = self.password_entry.get()
        
        if not login or not password:
            messagebox.showwarning("Ошибка", "Заполните все поля")
            return
            
        if len(login) < 3:
            messagebox.showwarning("Ошибка", "Логин должен содержать минимум 3 символа")
            return
            
        if len(password) < 4:
            messagebox.showwarning("Ошибка", "Пароль должен содержать минимум 4 символа")
            return
            
        if self.tracker.register_user(login, password):
            messagebox.showinfo("Успех", "Регистрация завершена!")
            self.root.destroy()
        else:
            messagebox.showerror("Ошибка", "Логин уже занят")

class MainWindow:
    def __init__(self, root, tracker):
        self.root = root
        self.tracker = tracker
        self.user_data = self.tracker.get_user_data()
        self.colors = self.tracker.colors['dark'] if self.user_data.get('dark_mode', False) else self.tracker.colors['light']
        self.setup_window()
        self.create_widgets()
        self.update_ui()
        self.root.mainloop()
        
    def setup_window(self):
        self.root.title("Копеечка")
        self.root.geometry("950x600")
        self.root.configure(bg=self.colors['bg'])
        center_window(self.root, 950, 600)
        
    def create_widgets(self):
        # Header
        header_frame = Frame(self.root, bg=self.colors['header'], height=80)
        header_frame.pack(fill=X)
        header_frame.pack_propagate(False)
        
        Label(header_frame, text="💰 Копеечка", font=("Arial", 18, "bold"), 
             bg=self.colors['header'], fg="white").pack(side=LEFT, padx=20)
        
        buttons_frame = Frame(header_frame, bg=self.colors['header'])
        buttons_frame.pack(side=RIGHT, padx=10)
        
        Button(buttons_frame, text="Настройки", command=self.open_settings,
              bg=self.colors['button'], fg="white", font=("Arial", 10), 
              relief=FLAT, padx=10, pady=5, activebackground=self.colors['button_active']).pack(side=LEFT, padx=2)
        
        Button(buttons_frame, text="Аналитика", command=self.show_analytics,
              bg=self.colors['button'], fg="white", font=("Arial", 10), 
              relief=FLAT, padx=10, pady=5, activebackground=self.colors['button_active']).pack(side=LEFT, padx=2)
        
        Button(buttons_frame, text="Удалить", command=self.delete_transaction,
              bg=self.colors['button'], fg="white", font=("Arial", 10), 
              relief=FLAT, padx=10, pady=5, activebackground=self.colors['button_active']).pack(side=LEFT, padx=2)
        
        Button(buttons_frame, text="Выйти", command=self.quit_app,
              bg=self.colors['error'], fg="white", font=("Arial", 10), 
              relief=FLAT, padx=10, pady=5, activebackground="#D45C5C").pack(side=LEFT, padx=2)
        
        # Main content
        content_frame = Frame(self.root, bg=self.colors['bg'])
        content_frame.pack(expand=True, fill=BOTH, padx=20, pady=20)
        
        # Left panel with balance
        left_frame = Frame(content_frame, bg=self.colors['bg'], width=300)
        left_frame.pack(side=LEFT, fill=Y)
        
        balance_frame = Frame(left_frame, bg=self.colors['frame'], padx=20, pady=20)
        balance_frame.pack(pady=20, fill=X)
        
        Label(balance_frame, text="Ваш баланс", font=("Arial", 16, "bold"), 
             bg=self.colors['frame'], fg=self.colors['text']).pack(anchor="w", pady=(0, 20))
        
        self.balance_label = Label(balance_frame, text="0 ₽", font=("Arial", 32, "bold"), 
                                  bg=self.colors['frame'], fg=self.colors['text'])
        self.balance_label.pack()
        
        # Right panel with transactions
        right_frame = Frame(content_frame, bg=self.colors['bg'], padx=20)
        right_frame.pack(side=RIGHT, fill=BOTH, expand=True)
        
        buttons_frame = Frame(right_frame, bg=self.colors['bg'])
        buttons_frame.pack(pady=20)
        
        Button(buttons_frame, text="Добавить доход", command=self.add_income, 
              bg=self.colors['button'], fg="white", font=("Arial", 14), 
              relief=FLAT, padx=20, pady=10, width=20,
              activebackground=self.colors['button_active']).grid(row=0, column=0, padx=10, pady=10)
        
        Button(buttons_frame, text="Добавить расход", command=self.add_expense, 
              bg=self.colors['button'], fg="white", font=("Arial", 14), 
              relief=FLAT, padx=20, pady=10, width=20,
              activebackground=self.colors['button_active']).grid(row=0, column=1, padx=10, pady=10)
        
        # Transactions treeview with style
        style = ttk.Style()
        style.configure("Treeview", 
                       background=self.colors['tree_bg'],
                       foreground=self.colors['tree_fg'],
                       fieldbackground=self.colors['tree_bg'])
        style.configure("Treeview.Heading", 
                       background=self.colors['button'],
                       foreground="white",
                       font=('Arial', 10, 'bold'))
        style.map("Treeview", 
                 background=[('selected', self.colors['button_active'])])
        
        self.transactions_tree = ttk.Treeview(right_frame, columns=("ID", "Дата", "Тип", "Категория", "Сумма", "Описание"), 
                                            show="headings", height=15)
        
        for col in ("ID", "Дата", "Тип", "Категория", "Сумма", "Описание"):
            self.transactions_tree.heading(col, text=col)
            self.transactions_tree.column(col, width=100, anchor='center')
        
        self.transactions_tree.column("ID", width=50)
        self.transactions_tree.column("Дата", width=120)
        self.transactions_tree.column("Описание", width=200)
        
        scrollbar = ttk.Scrollbar(right_frame, orient="vertical", command=self.transactions_tree.yview)
        self.transactions_tree.configure(yscrollcommand=scrollbar.set)
        
        self.transactions_tree.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill=Y)

    def add_income(self):
        self.show_transaction_window("income")

    def add_expense(self):
        self.show_transaction_window("expense")

    def show_transaction_window(self, transaction_type):
        transaction_window = Toplevel(self.root)
        TransactionWindow(transaction_window, self.tracker, transaction_type, self.update_ui)

    def delete_transaction(self):
        selected = self.transactions_tree.selection()
        if not selected:
            messagebox.showwarning("Ошибка", "Выберите транзакцию для удаления")
            return
            
        transaction_id = int(self.transactions_tree.item(selected[0])['values'][0])
        self.user_data["transactions"] = [t for t in self.user_data["transactions"] if t["id"] != transaction_id]
        
        self.user_data["balance"] = sum(
            t["amount"] if t["type"] == "income" else -t["amount"] 
            for t in self.user_data["transactions"]
        )
        
        self.tracker.save_user_data(self.user_data)
        self.update_ui()
        messagebox.showinfo("Успех", "Транзакция удалена")

    def show_analytics(self):
        analytics_window = Toplevel(self.root)
        AnalyticsWindow(analytics_window, self.user_data["transactions"])

    def open_settings(self):
        settings_window = Toplevel(self.root)
        SettingsWindow(settings_window, self.tracker, self.update_theme)

    def update_ui(self):
        """Обновляет интерфейс с текущими данными"""
        self.user_data = self.tracker.get_user_data()
        self.balance_label.config(text=f"{self.user_data['balance']} ₽")
        
        if self.user_data['balance'] > 0:
            self.balance_label.config(fg="#586144")
        elif self.user_data['balance'] < 0:
            self.balance_label.config(fg=self.colors['error'])
        else:
            self.balance_label.config(fg=self.colors['text'])
            
        for row in self.transactions_tree.get_children():
            self.transactions_tree.delete(row)
            
        for transaction in sorted(self.user_data["transactions"], key=lambda x: x.get("date", ""), reverse=True):
            self.transactions_tree.insert("", "end", values=(
                transaction.get("id", ""),
                transaction.get("date", ""),
                "Доход" if transaction.get("type") == "income" else "Расход",
                transaction.get("category", ""),
                f"{transaction.get('amount', 0)} ₽",
                transaction.get("description", "")
            ))

    def update_theme(self):
        """Полностью обновляет тему приложения"""
        self.user_data = self.tracker.get_user_data()
        self.colors = self.tracker.colors['dark'] if self.user_data.get('dark_mode', False) else self.tracker.colors['light']
        
        # Обновляем стиль Treeview
        style = ttk.Style()
        style.configure("Treeview", 
                      background=self.colors['tree_bg'],
                      foreground=self.colors['tree_fg'],
                      fieldbackground=self.colors['tree_bg'])
        style.configure("Treeview.Heading", 
                      background=self.colors['button'],
                      foreground="white",
                      font=('Arial', 10, 'bold'))
        style.map("Treeview", 
                background=[('selected', self.colors['button_active'])])
        
        # Обновляем цвета всех виджетов
        self.root.configure(bg=self.colors['bg'])
        
        # Обновляем UI чтобы применить изменения
        self.update_ui()

    def quit_app(self):
        self.root.quit()

class TransactionWindow:
    def __init__(self, root, tracker, transaction_type, callback):
        self.root = root
        self.tracker = tracker
        self.transaction_type = transaction_type
        self.callback = callback
        self.user_data = self.tracker.get_user_data()
        self.colors = self.tracker.colors['dark'] if self.user_data.get('dark_mode', False) else self.tracker.colors['light']
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        title = "Добавить доход" if self.transaction_type == "income" else "Добавить расход"
        self.root.title(title)
        self.root.geometry("400x400")
        self.root.resizable(False, False)
        self.root.configure(bg=self.colors['bg'])
        center_window(self.root, 400, 400)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg=self.colors['bg'], padx=30, pady=30)
        main_frame.pack(expand=True, fill=BOTH)
        
        Label(main_frame, text="Сумма:", bg=self.colors['bg'], fg=self.colors['text']).pack(anchor="w")
        self.amount_entry = Entry(main_frame, font=("Arial", 14), bg=self.colors['entry'], fg=self.colors['text'], 
                                insertbackground="white", relief=FLAT)
        self.amount_entry.pack(fill=X, ipady=8, pady=10)
        
        Label(main_frame, text="Категория:", bg=self.colors['bg'], fg=self.colors['text']).pack(anchor="w")
        
        categories = self.tracker.get_categories()[self.transaction_type]
        self.category_var = StringVar(value=categories[0])
        
        category_menu = OptionMenu(main_frame, self.category_var, *categories)
        category_menu.config(bg=self.colors['entry'], fg=self.colors['text'], 
                           activebackground=self.colors['button_active'], activeforeground="white")
        category_menu["menu"].config(bg=self.colors['entry'], fg=self.colors['text'])
        category_menu.pack(fill=X, pady=10)
        
        Label(main_frame, text="Описание:", bg=self.colors['bg'], fg=self.colors['text']).pack(anchor="w")
        self.description_entry = Entry(main_frame, font=("Arial", 14), bg=self.colors['entry'], fg=self.colors['text'], 
                                     insertbackground="white", relief=FLAT)
        self.description_entry.pack(fill=X, ipady=8, pady=10)
        
        Button(main_frame, text="Добавить", command=self.add_transaction,
              bg=self.colors['button'], fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground=self.colors['button_active']).pack(fill=X, pady=20)

    def add_transaction(self):
        try:
            amount = float(self.amount_entry.get())
            if amount <= 0:
                raise ValueError("Сумма должна быть положительной")
                
            transaction = {
                "id": len(self.tracker.get_user_data()["transactions"]) + 1,
                "type": self.transaction_type,
                "amount": amount,
                "category": self.category_var.get(),
                "description": self.description_entry.get(),
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            user_data = self.tracker.get_user_data()
            user_data["transactions"].append(transaction)
            
            if self.transaction_type == "income":
                user_data["balance"] += amount
            else:
                user_data["balance"] -= amount
                
            self.tracker.save_user_data(user_data)
            self.callback()
            self.root.destroy()
            messagebox.showinfo("Успех", "Транзакция добавлена")
        except ValueError as e:
            messagebox.showerror("Ошибка", f"Некорректные данные: {str(e)}")

class AnalyticsWindow:
    def __init__(self, root, transactions):
        self.root = root
        self.transactions = transactions
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Аналитика финансов")
        self.root.geometry("1100x600")
        self.root.configure(bg="#D4D4CE")
        center_window(self.root, 1100, 600)
        
    def create_widgets(self):
        notebook = ttk.Notebook(self.root)
        notebook.pack(expand=True, fill=BOTH, padx=20, pady=20)
        
        charts_frame = Frame(notebook, bg="#D4D4CE")
        notebook.add(charts_frame, text="Графики")
        self.create_charts(charts_frame)
        
        report_frame = Frame(notebook, bg="#D4D4CE")
        notebook.add(report_frame, text="Отчет")
        self.create_report(report_frame)

    def create_charts(self, parent):
        income_data = {}
        expense_data = {}
        
        for t in self.transactions:
            if t.get("type") == "income":
                income_data[t.get("category", "Другое")] = income_data.get(t.get("category", "Другое"), 0) + t.get("amount", 0)
            else:
                expense_data[t.get("category", "Другое")] = expense_data.get(t.get("category", "Другое"), 0) + t.get("amount", 0)
        
        if income_data:
            fig1, ax1 = plt.subplots(figsize=(5, 3))
            ax1.pie(income_data.values(), labels=income_data.keys(), autopct='%1.1f%%')
            ax1.set_title('Доходы по категориям')
            
            canvas1 = FigureCanvasTkAgg(fig1, master=parent)
            canvas1.draw()
            canvas1.get_tk_widget().pack(side=LEFT, padx=10, pady=10, fill=BOTH, expand=True)
        
        if expense_data:
            fig2, ax2 = plt.subplots(figsize=(5, 3))
            ax2.pie(expense_data.values(), labels=expense_data.keys(), autopct='%1.1f%%')
            ax2.set_title('Расходы по категориям')
            
            canvas2 = FigureCanvasTkAgg(fig2, master=parent)
            canvas2.draw()
            canvas2.get_tk_widget().pack(side=RIGHT, padx=10, pady=10, fill=BOTH, expand=True)

    def create_report(self, parent):
        total_income = sum(t.get("amount", 0) for t in self.transactions if t.get("type") == "income")
        total_expense = sum(t.get("amount", 0) for t in self.transactions if t.get("type") == "expense")
        balance = total_income - total_expense
        
        report_text = f"""
Финансовый отчет:

Общий доход: {total_income} ₽
Общий расход: {total_expense} ₽
Баланс: {balance} ₽

Количество операций:
- Доходы: {len([t for t in self.transactions if t.get("type") == "income"])}
- Расходы: {len([t for t in self.transactions if t.get("type") == "expense"])}

Последние 5 операций:
"""
        
        for t in sorted(self.transactions, key=lambda x: x.get("date", ""), reverse=True)[:5]:
            report_text += f"\n[{t.get('date', '')}] {t.get('type', '')} - {t.get('category', '')}: {t.get('amount', 0)} ₽ ({t.get('description', '')})"
        
        report_label = Label(parent, text=report_text, font=("Arial", 12), 
                           bg="#AEB6A5", fg="#424C3B", justify=LEFT, padx=20, pady=20)
        report_label.pack(fill=BOTH, expand=True)

class SettingsWindow:
    def __init__(self, root, tracker, callback):
        self.root = root
        self.tracker = tracker
        self.callback = callback
        self.categories = self.tracker.get_categories()
        self.user_data = self.tracker.get_user_data()
        self.colors = self.tracker.colors['dark'] if self.user_data.get('dark_mode', False) else self.tracker.colors['light']
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Настройки")
        self.root.geometry("500x600")
        self.root.resizable(False, False)
        self.root.configure(bg=self.colors['bg'])
        center_window(self.root, 500, 600)
        
    def create_widgets(self):
        notebook = ttk.Notebook(self.root)
        notebook.pack(expand=True, fill=BOTH, padx=20, pady=20)
        
        theme_frame = Frame(notebook, bg=self.colors['bg'])
        notebook.add(theme_frame, text="Тема")
        
        self.dark_mode_var = BooleanVar(value=self.user_data.get("dark_mode", False))
        Checkbutton(theme_frame, text="Темная тема", variable=self.dark_mode_var,
                   bg=self.colors['bg'], fg=self.colors['text'], selectcolor=self.colors['entry'], 
                   activebackground=self.colors['bg'], activeforeground=self.colors['text'], 
                   font=("Arial", 12)).pack(pady=20)
        
        categories_frame = Frame(notebook, bg=self.colors['bg'])
        notebook.add(categories_frame, text="Категории")
        
        Label(categories_frame, text="Категории доходов:", bg=self.colors['bg'], fg=self.colors['text']).pack(pady=(10, 5))
        self.income_categories_entry = Text(categories_frame, height=3, font=("Arial", 12), 
                                          bg=self.colors['entry'], fg=self.colors['text'], insertbackground="white")
        self.income_categories_entry.pack(fill=X, padx=10, pady=5)
        self.income_categories_entry.insert("1.0", ", ".join(self.categories["income"]))
        
        Label(categories_frame, text="Категории расходов:", bg=self.colors['bg'], fg=self.colors['text']).pack(pady=(10, 5))
        self.expense_categories_entry = Text(categories_frame, height=3, font=("Arial", 12), 
                                           bg=self.colors['entry'], fg=self.colors['text'], insertbackground="white")
        self.expense_categories_entry.pack(fill=X, padx=10, pady=5)
        self.expense_categories_entry.insert("1.0", ", ".join(self.categories["expense"]))
        
        Button(categories_frame, text="Сохранить", command=self.save_settings,
              bg=self.colors['button'], fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground=self.colors['button_active']).pack(fill=X, pady=20)

    def save_settings(self):
        income_cats = [cat.strip() for cat in self.income_categories_entry.get("1.0", "end-1c").split(",") if cat.strip()]
        expense_cats = [cat.strip() for cat in self.expense_categories_entry.get("1.0", "end-1c").split(",") if cat.strip()]
        
        if not income_cats or not expense_cats:
            messagebox.showerror("Ошибка", "Категории не могут быть пустыми")
            return
            
        self.categories = {
            "income": income_cats,
            "expense": expense_cats
        }
        
        self.user_data["dark_mode"] = self.dark_mode_var.get()
        self.tracker.save_user_data(self.user_data)
        
        self.tracker.save_categories(self.categories)
        
        messagebox.showinfo("Успех", "Настройки сохранены")
        self.callback()
        self.root.destroy()

def main():
    tracker = FinanceTracker()
    root = Tk()
    AuthWindow(root, tracker)

if __name__ == "__main__":
    main()